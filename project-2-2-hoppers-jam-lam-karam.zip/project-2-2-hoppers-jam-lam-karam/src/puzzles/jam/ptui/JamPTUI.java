package puzzles.jam.ptui;

import puzzles.common.Observer;
import puzzles.jam.gui.ConsoleApplication;
import puzzles.jam.model.JamModel;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class JamPTUI extends ConsoleApplication implements Observer<JamModel, String> {
    private JamModel model;
    public boolean init;
    private PrintWriter print;

    @Override
    public void init() throws Exception {
        this.init = false;
        this.model = new JamModel(super.getArguments().get(0));
        this.model.addObserver( this );

        List< String > paramStrings = super.getArguments();
        if ( paramStrings.size() == 1 ) {
            final String file = paramStrings.get( 0 );
            if ( model.files.contains(file) || new File(file).isDirectory()) {
                this.model.load( file );
            }
            else {
                throw new Exception(
                        String.format(
                                "\"%s\" is not the required word length (%d)." +
                                        System.lineSeparator(),
                                file
                        )
                );
            }
        }
        else {
            this.model.load("data/jam/jam-4.txt");
        }
    }

    @Override
    public void update(JamModel jamModel, String msg) {
        if (init) {
            if (jamModel.getConfig().isSolution()) {
                System.out.println(jamModel.getConfig());
                this.print.println("You Win!");
            }
            else {
                this.print.println(msg);
                System.out.println(jamModel.getConfig());
            }
        }
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java JamPTUI filename");
        }
        else {
            ConsoleApplication.launch(JamPTUI.class, args);
        }
    }


    public void start(PrintWriter console) throws Exception {
        this.print = console;
        this.init = true;
        super.setOnCommand( "r", 0, "\t\t\t-- Reset the current game.",
            args -> {
                try {
                    this.model.reset();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        );
        super.setOnCommand( "q", 0, "\t\t\t-- Quit the game",
                args -> {
                    try {
                        this.model.quit();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
        );
        super.setOnCommand("s", 2, "\t\t\t-- Select cell at r, c",
                args -> {
                    try {
                        this.model.select(args[0], args[1]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
        );
        super.setOnCommand("h", 0, "\t\t\t-- hint next move",
                args -> {
                    try {
                        this.model.hint();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
        );
        super.setOnCommand("l", 1, "\t\t\t-- load new puzzle file",
                args -> {
                    try {
                        this.model.load(args[0]);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
    }
}
