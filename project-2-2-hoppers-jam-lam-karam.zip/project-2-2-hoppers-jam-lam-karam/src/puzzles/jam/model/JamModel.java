package puzzles.jam.model;

import puzzles.common.Observer;
import puzzles.common.solver.Configuration;
import puzzles.common.solver.Solver;
import puzzles.jam.gui.JamGUI;
import puzzles.jam.ptui.JamPTUI;
import puzzles.jam.solver.Jam;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class JamModel {
    /** the collection of observers of this model */
    private final List<Observer<JamModel, String>> observers = new LinkedList<>();
    private boolean select2;
    private int row;
    private int col;
    private Car select;
    /** the current configuration */
    private JamConfig currentConfig;
    public String file;
    private boolean selected;
    public final ArrayList<String> files = new ArrayList<>(List.of("data/jam/jam-0.txt",
            "data/jam/jam-1.txt", "data/jam/jam-2.txt", "data/jam/jam-3.txt", "data/jam/jam-4.txt"
            ,"data/jam/jam-5.txt", "data/jam/jam-6.txt", "data/jam/jam-7.txt", "data/jam/jam-8.txt",
            "data/jam/jam-9.txt", "data/jam/jam-10.txt", "data/jam/jam-11.txt"));
    public ArrayList<Car> cars;


    public JamModel(String filename) throws IOException {
        this.currentConfig = new JamConfig(filename);
        file = filename;
        this.cars = new ArrayList<>();
        cars.addAll(currentConfig.cars);
        System.out.println("Loaded File" + file + "\n" + currentConfig);
    }

    /**
     * The view calls this to add itself as an observer.
     *
     * @param observer the view
     */

    public void addObserver(Observer<JamModel, String> observer) {
        this.observers.add(observer);
    }

    /**
     * The model's state has changed (the counter), so inform the view via
     * the update method
     */
    private void alertObservers(String msg) {
        for (var observer : observers) {
            observer.update(this, msg);
        }
    }

    public void select(String row, String col) {
        selected = false;
        if (Integer.parseInt(row) >= currentConfig.getRow() || Integer.parseInt(col) >= currentConfig.getCol()) {
                alertObservers("Out of bounds");
        }
        else {
            if (!selected && (currentConfig.board[Integer.parseInt(row)][Integer.parseInt(col)] != '.')) {
                selected = true;
                alertObservers("Selected (" + row + ", " + col + ")");
                for (Car car: currentConfig.cars) {
                    if (car.getName() == currentConfig.board[Integer.parseInt(row)][Integer.parseInt(col)]) {
                        select = car;
                    }
                }
            }
            else if (selected && (currentConfig.board[Integer.parseInt(row)][Integer.parseInt(col)] == '.')){
                if (select.vertical()) {
                    if (Integer.parseInt(col) == select.getEndCol()) {
                        if (Integer.parseInt(row) == select.getEndRow() + 1 || Integer.parseInt(row) < currentConfig.getRow()) {
                            cars.remove(select);
                            Car c = new Car(select.getName(), select.getStartRow() + 1, select.getStartCol(),
                            select.getEndRow() + 1, select.getEndCol());
                            cars.add(c);
                            for (int i = 0; i < currentConfig.getRow(); i++) {
                                for (int j = 0; j < currentConfig.getCol(); j++) {
                                    currentConfig.board[i][j] = '.';
                                }
                            }
                            for (Car a: cars) {
                                if (!a.vertical()) {
                                    for (int i = a.getStartCol(); i <= a.getEndCol(); i++) {
                                        currentConfig.board[a.getStartRow()][i] = a.getName();
                                    }
                                } else {
                                    for (int i = a.getStartRow(); i <= a.getEndRow(); i++) {
                                        currentConfig.board[i][a.getStartCol()] = a.getName();
                                    }
                                }
                            }
                            selected = false;
                            alertObservers(select.getName() + "was moved.");
                        }
                        else if (Integer.parseInt(row) == select.getEndRow() - 1 || Integer.parseInt(row) < currentConfig.getRow()) {
                            cars.remove(select);
                            Car c = new Car(select.getName(), select.getStartRow() - 1, select.getStartCol(),
                                    select.getEndRow() + 1, select.getEndCol());
                            cars.add(c);
                            for (int i = 0; i < currentConfig.getRow(); i++) {
                                for (int j = 0; j < currentConfig.getCol(); j++) {
                                    currentConfig.board[i][j] = '.';
                                }
                            }
                            for (Car a: cars) {
                                if (!a.vertical()) {
                                    for (int i = a.getStartCol(); i <= a.getEndCol(); i++) {
                                        currentConfig.board[a.getStartRow()][i] = a.getName();
                                    }
                                } else {
                                    for (int i = a.getStartRow(); i <= a.getEndRow(); i++) {
                                        currentConfig.board[i][a.getStartCol()] = a.getName();
                                    }
                                }
                            }
                            selected = false;
                            alertObservers(select.getName() + "was moved.");
                        }
                        else {
                            alertObservers("Invalid move.");
                        }
                    }
                    else {
                        alertObservers("Invalid move.");
                    }
                }
                if (!select.vertical()) {
                    if (Integer.parseInt(row) == select.getEndRow()) {
                        if (Integer.parseInt(col) == select.getEndCol() + 1 || Integer.parseInt(col) < currentConfig.getCol()) {
                            cars.remove(select);
                            Car c = new Car(select.getName(), select.getStartRow(), select.getStartCol() + 1,
                                    select.getEndRow(), select.getEndCol() + 1);
                            cars.add(c);
                            for (int i = 0; i < currentConfig.getRow(); i++) {
                                for (int j = 0; j < currentConfig.getCol(); j++) {
                                    currentConfig.board[i][j] = '.';
                                }
                            }
                            for (Car a: cars) {
                                if (!a.vertical()) {
                                    for (int i = a.getStartCol(); i <= a.getEndCol(); i++) {
                                        currentConfig.board[a.getStartRow()][i] = a.getName();
                                    }
                                } else {
                                    for (int i = a.getStartRow(); i <= a.getEndRow(); i++) {
                                        currentConfig.board[i][a.getStartCol()] = a.getName();
                                    }
                                }
                            }
                            selected = false;
                            alertObservers(select.getName() + "was moved.");
                        }
                        else if (Integer.parseInt(col) == select.getEndCol() - 1 || Integer.parseInt(col) < currentConfig.getCol()) {
                            cars.remove(select);
                            Car c = new Car(select.getName(), select.getStartRow(), select.getStartCol() - 1,
                                    select.getEndRow(), select.getEndCol() - 1);
                            cars.add(c);
                            for (int i = 0; i < currentConfig.getRow(); i++) {
                                for (int j = 0; j < currentConfig.getCol(); j++) {
                                    currentConfig.board[i][j] = '.';
                                }
                            }
                            for (Car a: cars) {
                                if (!a.vertical()) {
                                    for (int i = a.getStartCol(); i <= a.getEndCol(); i++) {
                                        currentConfig.board[a.getStartRow()][i] = a.getName();
                                    }
                                } else {
                                    for (int i = a.getStartRow(); i <= a.getEndRow(); i++) {
                                        currentConfig.board[i][a.getStartCol()] = a.getName();
                                    }
                                }
                            }
                            selected = false;
                            alertObservers(select.getName() + "was moved.");
                        }
                        else {
                            alertObservers("Invalid move.");
                        }
                    }
                    else {
                        alertObservers("Invalid move.");
                    }
                }
                alertObservers("Invalid move.");
            }
        }
    }

    public JamConfig getConfig() {
        return currentConfig;
    }

    public void load(String filename) throws IOException {
        try {
            File file1 = new File(filename);
            file = filename;
            this.currentConfig = new JamConfig(file);
            alertObservers("New Game Loaded\n" + file1.getName());
        } catch (FileNotFoundException e) {
            alertObservers("Invalid file: " + filename  + "\n Loaded file: " + file);
        }
    }

    public void hint() {
        Solver solver = new Solver();
        Collection<Configuration> next = solver.Solve(currentConfig);
        if (!next.isEmpty()) {
            Object[] solution = next.toArray();
            currentConfig = (JamConfig) solution[1];
            alertObservers("hint\n");
        }
    }

    public void reset() throws IOException {
        currentConfig = new JamConfig(file);
        selected = false;
        alertObservers("Reset");
    }

    public void quit() {
        System.exit(1);
    }
}
