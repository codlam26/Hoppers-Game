package puzzles.jam.model;

import java.util.ArrayList;

public class Car {

    private char car;
    private int startRow;
    private int startCol;
    private int endRow;
    private int endCol;

    public Car (char car, int startRow, int startCol, int endRow, int endCol) {
        this.car = car;
        this.startRow = startRow;
        this.startCol = startCol;
        this.endRow = endRow;
        this.endCol = endCol;
    }

    public char getName() {
        return car;
    }


    public int getStartRow() {
        return startRow;
    }

    public int getStartCol() {
        return startCol;
    }

    public int getEndRow() {
        return endRow;
    }

    public int getEndCol() {
        return endCol;
    }

    public boolean vertical() {
        return startRow != endRow;
    }

    public boolean equals(Object other) {
        boolean end = false;
        if (other instanceof Car otherCar) {
            end = this.endCol == otherCar.endCol && this.getStartCol() == otherCar.getStartCol() && this.getEndRow() == ((Car) other).getEndRow()
                    && this.getEndCol() == otherCar.getEndCol() && this.getName() == (otherCar.getName());
        }
        return end;
    }
}
