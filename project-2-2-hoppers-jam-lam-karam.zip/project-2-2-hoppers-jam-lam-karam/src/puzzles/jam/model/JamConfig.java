package puzzles.jam.model;

import puzzles.common.solver.Configuration;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class JamConfig implements Configuration{

    public char[][] board;
    public int row;
    public int col;
    private int numCars;
    private final static char EMPTY = '.';
    public ArrayList<Car> cars = new ArrayList<>();
    private ArrayList<Configuration> neighbors;

    public JamConfig(String filename) throws IOException {
        try (BufferedReader in = new BufferedReader(new FileReader(filename))) {
            // read first line: rows cols
            String[] fields = in.readLine().split("\\s+");
            this.row = Integer.parseInt(fields[0]);
            this.col = Integer.parseInt(fields[1]);
            neighbors = new ArrayList<>();

            this.board = new char[row][col];
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    board[i][j] = EMPTY;
                }
            }
            numCars = Integer.parseInt(in.readLine());
            String line = in.readLine();
            while (line != null) {
                String[] carInfo;
                carInfo = line.split("\\s+");
                char name = carInfo[0].charAt(0);
                int startRow = Integer.parseInt(carInfo[1]);
                int startCol = Integer.parseInt(carInfo[2]);
                int endRow = Integer.parseInt(carInfo[3]);
                int endCol = Integer.parseInt(carInfo[4]);
                Car a = new Car(name, startRow, startCol, endRow, endCol);
                cars.add(a);
                line = in.readLine();

            }
            for (Car a: cars) {
                if (!a.vertical()) {
                    for (int i = a.getStartCol(); i <= a.getEndCol(); i++) {
                        board[a.getStartRow()][i] = a.getName();
                    }
                } else {
                    for (int i = a.getStartRow(); i <= a.getEndRow(); i++) {
                        board[i][a.getStartCol()] = a.getName();
                    }
                }
            }
        }
    }

    public JamConfig (JamConfig jc, ArrayList<Car> cars){
        this.row = jc.getRow();
        this.col = jc.getCol();
        this.cars = cars;
        this.board = new char[row][col];
        neighbors = new ArrayList<>();
        for (int i = 0; i < row; i++) {
            Arrays.fill(board[i], EMPTY);
        }
        for (Car a: cars) {
            if (!a.vertical()) {
                for (int i = a.getStartCol(); i <= a.getEndCol(); i++) {
                    board[a.getStartRow()][i] = a.getName();
                }
            } else {
                for (int i = a.getStartRow(); i <= a.getEndRow(); i++) {
                    board[i][a.getStartCol()] = a.getName();
                }
            }
        }

    }

    @Override
    public boolean isSolution() {
        for (int i = 0; i < row; i++) {
            if (board[i][col - 1] == 'X') {
                return true;
            }
        }
        return false;
    }

    @Override
    public Collection<Configuration> getNeighbors() {
        ArrayList<Car> cars2 = new ArrayList<>();
        cars2 = (ArrayList<Car>) cars.clone();
        for (int i = 0; i < cars.size(); i++) {
            Car tempCar = cars.get(i);
            if (cars.get(i).vertical()) {
                if (tempCar.getStartRow() - 1 >= 0) {
                    if (board[cars.get(i).getStartRow() - 1][cars.get(i).getStartCol()] == EMPTY) {
                        Car newCar = new Car(cars.get(i).getName(), tempCar.getStartRow() - 1, cars.get(i).getStartCol(), cars.get(i).getEndRow() - 1, cars.get(i).getEndCol());
                        cars2.remove(tempCar);
                        cars2.add(newCar);
                        JamConfig newJam = new JamConfig(this, cars2);
//                        cars2.remove(newCar);
//                        cars2.add(tempCar);
                        neighbors.add(newJam);
                    }
                }
                if (tempCar.getEndRow() + 1 < row) {
                    if (board[cars.get(i).getEndRow() + 1][cars.get(i).getEndCol()] == EMPTY) {
                        Car newCar = new Car(cars.get(i).getName(), cars.get(i).getStartRow() + 1, cars.get(i).getStartCol(), cars.get(i).getEndRow() + 1, cars.get(i).getEndCol());
                        cars2.remove(tempCar);
                        cars2.add(newCar);
                        JamConfig newJam = new JamConfig(this, cars2);
//                        cars2.remove(newCar);
//                        cars2.add(tempCar);
                        neighbors.add(newJam);

                    }
                }
            }
            else {
                if (tempCar.getStartCol()-1 >= 0) {
                    if (board[cars.get(i).getStartRow()][cars.get(i).getStartCol() - 1] == EMPTY) {
                        Car newCar = new Car(cars.get(i).getName(), cars.get(i).getStartRow(), cars.get(i).getStartCol() - 1, cars.get(i).getEndRow(), cars.get(i).getEndCol() - 1);
                        cars2.remove(tempCar);
                        cars2.add(newCar);
                        JamConfig newJam = new JamConfig(this, cars2);
//                        cars2.remove(newCar);
//                        cars2.add(tempCar);
                        neighbors.add(newJam);

                    }
                }
                if (tempCar.getEndCol() + 1 < col) {
                    if (board[cars.get(i).getEndRow()][cars.get(i).getEndCol() + 1] == EMPTY) {
                        Car newCar = new Car(cars.get(i).getName(), cars.get(i).getStartRow(), cars.get(i).getStartCol() + 1, cars.get(i).getEndRow(), cars.get(i).getEndCol() + 1);
                        cars2.remove(tempCar);
                        cars2.add(newCar);
                        JamConfig newJam = new JamConfig(this, cars2);
//                        cars2.remove(newCar);
//                        cars2.add(tempCar);
                        neighbors.add(newJam);
                    }
                }
            }
        }
        return neighbors;
    }

    public int hashCode() {
        int code = cars.hashCode();
        return code + Arrays.deepHashCode(board);
    }

    public boolean equal(Object other) {
        boolean end = false;
        int count = 0;
        if (other instanceof JamConfig jc2) {
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    if (this.board[i][j] == (jc2.board[i][j])){
                        count++;
                    }
                }
            }
            end = (count == row * col);
        }
        return end;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public char getVal(int row, int col) {
        return board[row][col];
    }

    @Override
    public String toString() {
        StringBuilder string = new StringBuilder();
        for (int i = 0; i < col; i++) {
            for (int j = 0; j < row; j++) {
                string.append(getVal(i, j)).append(" ");
            }
            string.append("\n");
        }
        return String.valueOf(string);
    }
}
