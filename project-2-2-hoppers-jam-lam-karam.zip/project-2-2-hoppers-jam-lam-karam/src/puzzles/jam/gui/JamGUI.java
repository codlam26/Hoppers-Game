package puzzles.jam.gui;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import puzzles.common.Observer;
import puzzles.jam.model.Car;
import puzzles.jam.model.JamConfig;
import puzzles.jam.model.JamModel;
import puzzles.jam.solver.Jam;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;


public class JamGUI extends Application implements Observer<JamModel, String>  {
    /** The resources directory is located directly underneath the gui package */
    private final static String RESOURCES_DIR = "resources/";

    // for demonstration purposes
    private final static String X_CAR_COLOR = "#DF0101";
    private final static int BUTTON_FONT_SIZE = 20;
    private final static int ICON_SIZE = 75;
    private final static char EMPTY = '.';
    private BorderPane game;
    private JamConfig jamConfig;
    public Label box;
    private Stage stage;
    private JamModel model;

    public void init() throws IOException {
        String filename = getParameters().getRaw().get(0);
        this.model = new JamModel(filename);
        model.addObserver(this);
        jamConfig = model.getConfig();
        box = new Label("Loaded: " + filename);
    }

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        GridPane grid = makeGame();
        GridPane buttons = new GridPane();
        game = new BorderPane(grid);
        Button load = new Button("load");
        load.setOnAction(ActionEvent -> {
            FileChooser chooser = new FileChooser();
            String currentPath = Paths.get(".").toAbsolutePath().normalize().toString();
            currentPath += File.separator + "data" + File.separator + "hoppers";
            chooser.setInitialDirectory(new File(currentPath));
            File f = chooser.showOpenDialog(stage);
            model.file = f.getPath();
            try {
                model.load(model.file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        Button reset = new Button("reset");
        reset.setOnAction(ActionEvent -> {
            try {
                model.reset();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        Button hint = new Button("hint");
        hint.setOnAction(ActionEvent -> model.hint());
        buttons.add(load, 3, 1);
        buttons.add(reset, 4, 1);
        buttons.add(hint, 5, 1);
        game.setTop(box);
        box.setAlignment(Pos.CENTER);
        game.setBottom(buttons);
        buttons.setAlignment(Pos.CENTER);
        Scene scene = new Scene(game);
        stage.setScene(scene);
        stage.show();
    }


    @Override
    public void update(JamModel jamModel, String msg) {
        if (model.getConfig().isSolution()) {
            game.setCenter(makeGame());
            jamConfig = model.getConfig();
            box.setText("You Win!");
            game.setCenter(makeGame());
        }
        else {
            box.setText(msg);
            jamConfig = model.getConfig();
            stage.sizeToScene();
        }
    }

   public GridPane makeGame() {
        GridPane grid = new GridPane();
        for (int i = 0; i < jamConfig.getRow(); i++) {
            for (int j = 0; j < jamConfig.getCol(); j++) {
                if (jamConfig.board[i][j] == EMPTY) {
                    Button button = new Button("");
                    int finalI1 = i;
                    int finalJ1 = j;
                    button.setOnAction(ActionEvent -> model.select(String.valueOf(finalI1), String.valueOf(finalJ1)));
                    grid.add(button, j, i);
                    button.setMaxSize(ICON_SIZE, ICON_SIZE);
                    button.setMinSize(ICON_SIZE, ICON_SIZE);

                }
                else if (jamConfig.board[i][j] == 'X'){
                    Button button = new Button("X");
                    int finalI1 = i;
                    int finalJ1 = j;
                    button.setOnAction(ActionEvent -> model.select(String.valueOf(finalI1), String.valueOf(finalJ1)));
                    button.setStyle(
                            "-fx-font-size: " + BUTTON_FONT_SIZE + ";" +
                                    "-fx-background-color: " + X_CAR_COLOR + ";" +
                                    "-fx-font-weight: bold;");
                    grid.add(button, j, i);
                    button.setMaxSize(ICON_SIZE, ICON_SIZE);
                    button.setMinSize(ICON_SIZE, ICON_SIZE);


                }
                else {
                    Button button = new Button(String.valueOf(jamConfig.board[i][j]));
                    int finalI1 = i;
                    int finalJ1 = j;
                    button.setOnAction(ActionEvent -> model.select(String.valueOf(finalI1), String.valueOf(finalJ1)));
                    button.setStyle(
                            "-fx-font-size: " + BUTTON_FONT_SIZE + ";" +
                                    "-fx-background-color: " + "#FFFF00" + ";" +
                                    "-fx-font-weight: bold;");

                    int finalJ = j;
                    int finalI = i;
                    button.setOnAction(ActionEvent -> model.select(String.valueOf(finalI), String.valueOf(finalJ)));
                    grid.add(button, j, i);
                    button.setMaxSize(ICON_SIZE, ICON_SIZE);
                    button.setMinSize(ICON_SIZE, ICON_SIZE);
                }
            }
        }
        return grid;
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
