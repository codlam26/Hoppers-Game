package puzzles.jam.solver;

import puzzles.common.solver.Configuration;
import puzzles.common.solver.Solver;
import puzzles.crossing.CrossingConfig;
import puzzles.jam.model.JamConfig;

import java.io.IOException;
import java.util.LinkedList;

import static puzzles.common.solver.Solver.Solve;

public class Jam {
    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            System.out.println("Usage: java Jam filename");
        }
        else {
            JamConfig jc = new JamConfig(args[0]);
            LinkedList<Configuration> a = (LinkedList<Configuration>) Solve(jc);
            System.out.println("Total configs: " + Solver.getTotConfigCount());
            System.out.println("Unique configs: " + Solver.getUniConfigCount());
            for(int i = 0; i < a.size();i++){
                System.out.println("Step " + i + ":\n" + a.get(i));
            }

        }
    }
}