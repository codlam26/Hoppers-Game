package puzzles.crossing;

import puzzles.common.solver.Configuration;
import puzzles.common.solver.Solver;

import java.util.LinkedList;

import static puzzles.common.solver.Solver.Solve;
/**
 * Author: Cody Lam
 **/

public class Crossing {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println(("Usage: java Crossing pups wolves"));
        } else {
            System.out.println("Pups: " + args[0] + " Wolves: " + args[1]);
            int pups = Integer.parseInt(args[0]);
            int wolves = Integer.parseInt(args[1]);
            int[] leftSide = new int[2];
            int[] rightSide = new int[2];
            leftSide[0] = pups;
            leftSide[1] = wolves;
            CrossingConfig ct = new CrossingConfig(leftSide, rightSide, true);
            LinkedList<Configuration> a = (LinkedList<Configuration>) Solve(ct);
            System.out.println("Total configs: " + Solver.getTotConfigCount());
            System.out.println("Unique configs: " + Solver.getUniConfigCount());
            for(int i = 0; i < a.size();i++){
            if(!a.get(a.size() -1 ).isSolution()){
                System.out.println("No solution");
                break;
            }
                System.out.println("Step " + i + ":" + a.get(i));
            }

        }
    }
}
