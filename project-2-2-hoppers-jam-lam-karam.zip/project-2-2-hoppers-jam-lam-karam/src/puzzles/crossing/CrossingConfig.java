package puzzles.crossing;

import puzzles.common.solver.Configuration;

import java.util.*;
/**
 * Author: Cody Lam
 */
public class CrossingConfig implements Configuration{
    private int[] leftBoat;
    private int[] rightBoat;
    private int[] left2;
    private int[] right2;
    private boolean OnLeftSide;
    public HashSet<Configuration> neighbors = new HashSet<>();


    /**
     * This is the constructor for the class
     * @param leftSide this is the array of the pups and wolves on the left side of the river
     * @param rightSide this is the array of the pups and wolves on the right side of the river
     * @param isLeft this will tell us whether the boat is on the left or the right side of the river
     */
    public CrossingConfig(int[]leftSide, int[]rightSide, boolean isLeft){
        leftBoat = Arrays.copyOf(leftSide,2);
        rightBoat = Arrays.copyOf(rightSide,2);
        left2 = leftBoat;
        right2 = rightBoat;
        OnLeftSide = isLeft;
    }

    /**
     * This is a method that will return true if the left side has no pups and no wolves
     * @return returns true if there are no pups and wolves on the left side of the river
     */
    @Override
    public boolean isSolution() {
        for(int i = 0; i < leftBoat.length -1;i++){
            if(leftBoat[i] == 0 && leftBoat[leftBoat.length -1] == 0){
                return true;
            }
        }
        return false;
    }

    /**
     * This method configures all the possibilities that the wolves and pups can move, and then when the pups and
     * wolves are moved, the array of the left boat and the right boat will be added into the collection of neighbors
     * @return
     */
    @Override
    public Collection<Configuration> getNeighbors() {
        Configuration w;
        if(!OnLeftSide){
            rightBoat[0] -= 1;
            leftBoat[0] += 1;
            w = new CrossingConfig(leftBoat, rightBoat,true);
            neighbors.add(w);
            rightBoat[0] += 1;
            leftBoat[0] -= 1;
        }

        if (OnLeftSide) {
            if(leftBoat[0] == 0 && leftBoat[1] > 0){
                leftBoat[1] -= 1;
                rightBoat[1] += 1;
                w =new CrossingConfig(leftBoat,rightBoat,false);
                neighbors.add(w);
                leftBoat[1] += 1;
                rightBoat[1] -= 1;
            }
            if(leftBoat[0] == 1){
                leftBoat[1] -= 1;
                rightBoat[1] += 1;
                w = new CrossingConfig(leftBoat, rightBoat,false);
                neighbors.add(w);
                leftBoat[1] += 1;
                rightBoat[1] -= 1;
            }
            if(leftBoat[0] >= 2) {
                leftBoat[0] -= 2;
                rightBoat[0] += 2;
                w = new CrossingConfig(leftBoat, rightBoat,false);
                neighbors.add(w);
                leftBoat[0] += 2;
                rightBoat[0] -= 2;
            }
            else{
                leftBoat[0] -= 1;
                rightBoat[1] += 1;
                w = new CrossingConfig(leftBoat, rightBoat,false);
                neighbors.add(w);
                leftBoat[0]+= 1;
                rightBoat[1] -= 1;
                }
            if(leftBoat[0] < 0 || rightBoat[0] < 0 || leftBoat[1] < 0 || rightBoat[1] < 0){
                neighbors.remove(w);

            }
        }
        return neighbors;
    }

    /**
     * This method will compare to objects and check whether they are equal or not
     * @param o this is the object that is being compared
     * @return it will return the result of whether the objects are equal, true if they are and false if they aren't
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CrossingConfig that = (CrossingConfig) o;
        return OnLeftSide == that.OnLeftSide && Arrays.equals(leftBoat, that.leftBoat) && Arrays.equals(rightBoat, that.rightBoat);
    }

    /**
     * this method will return the hashcode of left side of the river
     * @return it will return the hashcode of right side of the river
     */
    @Override
    public int hashCode() {
        int result = Objects.hash(OnLeftSide);
        result = 31 * result + Arrays.hashCode(leftBoat);
        result = 31 * result + Arrays.hashCode(rightBoat);
        return result;
    }

    /**
     * This method will print out the string of the amount of pups and wolves on the left side and the right side
     * and where the boat is located.
     * @return
     */
    @Override
    public String toString(){
        if(OnLeftSide){
            return (("(BOAT)") + "left=" + Arrays.toString(leftBoat) +", " +"right=" + Arrays.toString(rightBoat));
        }
        return  "      left=" + Arrays.toString(leftBoat) + "right=" + ", "+ Arrays.toString(rightBoat) + "\t(BOAT)";
    }
}

