package puzzles.strings;

import puzzles.common.solver.Configuration;

import java.util.Collection;
import java.util.HashSet;
/**
 * Author: Cody Lam
 */

public class StringsConfig implements Configuration {
    private String start;
    private static String end;


    /**
     * This is the constructor of the class
     * @param args this is the starting string
     */
    public StringsConfig(String args){
        this.start = args;

    }

    /**
     * sets the end string so that we are able to use isSolution
     * @param arg
     */
    public static void StringsEnd(String arg){
        end = arg;
    }

    /**
     * This method will return true if the start string that is being changed equals to the end string
     * @return it will return true if the start string equals the end string, otherwise false
     */
    @Override
    public boolean isSolution() {
        if(start.equals(end)){
            return true;
        }
        return false;
    }

    /**
     * This method gets the neighbors of the letter of a string either forward or backward on the ASCII table
     * @return it will return the collection of neighbors of that letter of the string
     */
    @Override
    public Collection<Configuration> getNeighbors() {
        HashSet<Configuration> neighbors = new HashSet<>();
        for(int j = 0; j < start.length();j++) {
            int inc = (start.charAt(j));
            int dec = (start.charAt(j));

            StringBuilder incString = new StringBuilder(start);
            StringBuilder decString = new StringBuilder(start);

            if (dec - 1 == 64) {
                dec = 91;
            }
            dec -= 1;
            decString.setCharAt(j,(char)dec);
            neighbors.add(new StringsConfig(decString.toString()));

            if (inc + 1 == 92) {
                inc = 64;
            }
            inc += 1;
            incString.setCharAt(j,(char)inc);
            neighbors.add(new StringsConfig(incString.toString()));
        }
        return neighbors;
    }

    /**
     * This method will compare to objects and check whether they are equal or not
     * @param other this is the object that is being compared
     * @return it will return the result of whether the objects are equal, true if they are and false if they aren't
     */
    @Override
    public boolean equals(Object other){
        boolean result = false;
        if(other instanceof StringsConfig){
            result = this.start.equals(((StringsConfig)other).start);
        }
        return result;
    }

    /**
     * this method will return the hashcode of the start string
     * @return it will return the hashcode of the starting string
     */
    @Override
    public int hashCode(){
        return start.hashCode();
    }

    /**
     * This method will return a string of the starting string and how it changes overtime
     * @return it returns the string that is being modified overtime.
     */
    @Override
    public String toString(){
        return start;
    }
}
