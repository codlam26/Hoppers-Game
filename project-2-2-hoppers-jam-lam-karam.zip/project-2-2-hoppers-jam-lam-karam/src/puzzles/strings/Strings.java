package puzzles.strings;

import puzzles.common.solver.Configuration;
import puzzles.common.solver.Solver;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedList;

import static puzzles.common.solver.Solver.Solve;
/**
 * Author: Cody Lam
 */
public class Strings {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println(("Usage: java Strings start finish"));
        } else {
            System.out.println("Start:" + args[0] + ", End: " + args[1]);
            StringsConfig st = new StringsConfig(args[0]);
            StringsConfig.StringsEnd(args[1]);
            LinkedList<Configuration> a = (LinkedList<Configuration>) Solve(st);


            System.out.println("Total configs: " + Solver.getTotConfigCount());
            System.out.println("Unique configs: " + Solver.getUniConfigCount());
            for(int i = 0; i < a.size();i++){
                if(!a.get(a.size() - 1).isSolution()){
                    System.out.println("No solution");
                    break;
                }
                System.out.println(("Step " + i +":" + a.get(i)));
            }


        }
    }
}
